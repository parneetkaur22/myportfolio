<?php include 'includes/header.php' ?>
    <!-- Hero Start -->
    <section class="hero-area jarallax over-layer-black">
        <img class="jarallax-img" src="<?php echo base_url('assets/images/bg/5.jpg')?>" alt="">
		<div class="row home-text_paty ">
        <div class="col-md-12 hero-content">
            <div class="hero-content-center">
                <div class="container">
                  
                      <div class="line-space"></div>
                            <div class="hero-col">
                                <h2>Hello,<br>a bit <span>about me</span></h2>
                                <h3 class="cd-headline clip">
                                    <span class="cd-words-wrapper">
                                        
                                        <b class="is-visible">Strong interpersonal and leadership skills. </b>
                                        <b>I am active and enthusiastic.</b>
                                    </span>
                                </h3>
								
								
								
                            </div>
                       
                   
                </div>
            </div>
        </div>

	
					 <div class="container circles_home" >
            <div class="row ">
                <div class="col-lg-4 col-md-4 col-sm-4 col-12 cirle12">
                   <a href="<?php echo base_url('about')?>"> <div class="counter-col">
                        <i class="icon icon-Files"></i>
                       
                        <p>About Me</p>
                    </div></a>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-12 cirle12">
                     <a href="<?php echo base_url('personalqualities')?>">  <div class="counter-col">
                        <i class="icon icon-Like"></i>
                       
                        <p>Personal Qualities</p>
                    </div></a>
                </div>
               
				<div class="col-lg-4 col-md-4 col-sm-4 col-12 cirle12">
                      <a href="<?php echo base_url('workexperience')?>"> <div class="counter-col">
                        <i class="icon icon-Crown"></i>
                        
                        <p>Work Experience</p>
                    </div></a>
                </div>
               
            </div>
        </div>
				
	</div>

        <a href="#about" class="scroll-animate-icon page-scroll">
           <!-- <i class="fa fa-angle-double-down faa-falling animated"></i>-->
        </a>
    </section>
	
	
	
    <!-- About Start -->
    <section class="about-area " id="about">
        <div class="container" >
            <div class="row">
                <div class="col-lg-7">
                    <div class="about-col">
                        <img src="<?php echo base_url('assets/images/about/about.jpg')?>" alt="">
                        <div class="about-content">
                            <h2>About <span>Me</span></h2>
                            <div class="title-bdr"></div>
                            <p>I’m Parneet kaur, I’m 20 years old, basically I belong to India but I moved to Canada in 2016, Recently i am pursuing my Interactive media design web diploma at Georgian College Barrie,Ontario. Before this I have completed my schooling from Narain Public School (PUNJAB), India in 2015 and these days I am  doing my co-op at Web-Studio Toronto here I write content for Web-Studio sites, ...</p>
                         
                            <!-- Modal HTML embedded directly into document -->
                          
                            <!-- Link to open the modal -->
                            <a class="btn btn-default btn-style btn-color" href="home/about" rel="modal:open">More about us</a>
                            
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    
                </div>
            </div>
                 </div>
    </section>

    <!-- Service Start -->
  

    <!-- Counter Start -->
 

    <!-- Portfolio Section -->


    <!-- Hire me Start -->
   
    <!-- Blog start -->
   

    <!-- Newsletter start -->
  

<?php include 'includes/footer.php' ?>