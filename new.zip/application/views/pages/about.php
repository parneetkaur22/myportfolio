<?php include 'includes/header.php';?>    
   <!-- Hero Start -->
    <section class="hero-area jarallax over-layer-black inner-pages personal-quality-page">
        <img class="jarallax-img" src="<?php echo base_url('assets/images/bg/1.jpg')?>" alt="">
        <div class="hero-content">
            <div class="hero-content-center">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="hero-col">
                             
                                <h3 class="cd-headline clip">
                                    <span class="cd-words-wrapper">
                                        <b class="is-visible">About me</b>
                                        <b>About me</b>
                                          <b>About me</b>
										     <b>About me</b>
                                    </span>
                                </h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <a href="#about" class="scroll-animate-icon page-scroll">
            <!--<i class="fa fa-angle-double-down faa-falling animated"></i>-->
        </a>
    </section>

    <!-- About Start -->
    <section class="about-area inner-pages-about portfolio-about" id="about">
	 <div class="col-md-12">
                    <div class="default-title text-center">
                        <h2>About Me</h2>
                        <div class="default-title-bdr"></div>
                        <p>It is a long established fact that a reader will be distracted.</p>
                    </div>
                </div>
        <div class="container">
            <div class="row">
			<div class="col-lg-6">
                     <img src="<?php echo base_url('assets/images/about/a12.png')?>" alt="">
                </div>
                <div class="col-lg-6">
                    <div class="about-col">
                       
                        <div class="about-content about-us">
                        
                            <p>I’m Parneet kaur, I’m 20 years old, basically I belong to India but I moved to Canada in 2016, Recently i am pursuing my Interactive media design web diploma at Georgian College Barrie,Ontario. Before this I have completed my schooling from Narain Public School (PUNJAB), India in 2015 and these days I am  doing my co-op at Web-Studio Toronto here I write content for Web-Studio sites, I am a Content Writer also I am doing my Security Job. </p>
							  <p>These days I am living in Toronto. It’s a very nice city, I have seen many worth-seeing places I just love that places. I have learned so many things when I came to Canada, I get some good days some bad, but I never give-up I always believe in hard-work because we do hard-work then definitely we will get good results. </p>
							    <p> As I already mentioned that my dream is to be an Police officer, and my hobbies-I love listening music and I am also a photographer not the professional one, but basic one, I love to click pictures, whenever I get time mostly I go to beach or Islands there are lot of things to click picture. Instead of going to malls and noisy areas I prefer to visit peaceful place specially parks too. </p>
                          
                            
                         
                        </div>
                    </div>
                </div>
                
            </div>
            </div>
            </div>
           
           
    </section>

    <!-- Testimonial Start -->
  
   <?php include 'includes/footer.php'?>
  