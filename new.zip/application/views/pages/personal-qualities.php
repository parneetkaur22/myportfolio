<?php include 'includes/header.php'?>
    <!-- Hero Start -->
    <section class="hero-area jarallax over-layer-black inner-pages personal-quality-page">
             <img class="jarallax-img" src="<?php echo base_url('assets/images/bg/1.jpg')?>" alt="">
        <div class="hero-content">
            <div class="hero-content-center">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="hero-col">
<h3 class="cd-headline clip">
                                    <span class="cd-words-wrapper">
                                        <b class="is-visible">Personal Qualities</b>
                                        <b>Personal Qualities</b>
                                        <b>Personal Qualities</b>
                                        <b>Personal Qualities</b>
                                    </span>
                                </h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </section>

    <!-- Service Start -->
    <section class="service-area" id="service">
	 <div class="col-md-12">
                    <div class="default-title text-center">
                        <h2>Personal Qualities
</h2>
                        <div class="default-title-bdr"></div>
                        <p>It is a long established fact that a reader will be distracted.</p>
                    </div>
                </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!--div class="default-title text-center">
                        <h2>My Personal Qualities</h2>
                        <div class="default-title-bdr"></div>
                        <p>It is a long established fact that a reader will be distracted.</p>
                    </div-->
					<div class="row personal-quality-text">
					<div class="col-md-8">
					<ul class="ul_personal-quality">
					
					
<li>Strong work ethics with remarkable customer handling skills.</li>
<li>Excellent communication skills in written and verbal both.</li>
<li>Remarkable patience with reliability and responsibility.</li>
<li>I have ability to meet the deadline of the work.</li>
<li>I can easily manage everything.</li>
<li>I am very puntual person and always do work on time.</li>
<li>I have ability to work well under pressure, and possess problem-solving skills.</li>
<li>I am hardworking as well as honest person and confident too.</li>
<li>Strong interpersonal and leadership skills.</li>
<li>I am active and enthusiastic.</li>
<li>Strong time management skills.</li>
<li>I love to help others, in every situation always ready to help others.</li>
					</ul>
					
					
                </div>
				<div class="col-md-4 img-part_p_q">
<img src="<?php echo base_url('assets/images/about/personal-quality.jpg')?> ">
				
				</div>				
				</div>				
                </div>
            </div>
                </div>
    </section>

  <?php include 'includes/footer.php' ?>