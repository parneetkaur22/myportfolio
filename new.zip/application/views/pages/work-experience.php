<?php include 'includes/header.php'?>
    <!-- Hero Start -->
    <section class="hero-area jarallax over-layer-black inner-pages personal-quality-page">
             <img class="jarallax-img" src="<?php echo base_url('assets/images/bg/1.jpg')?>" alt="">
        <div class="hero-content">
            <div class="hero-content-center">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="hero-col">
<h3 class="cd-headline clip">
                                    <span class="cd-words-wrapper">
                                        <b class="is-visible">Work Experience</b>
                                        <b>Work Experience</b>
                                        <b>Work Experience</b>
                                        <b>Work Experience</b>
                                        
                                    </span>
                                </h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </section>

     <!-- Service Start -->
    <section class="service-area" id="service">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="default-title text-center">
                        <h2>Work Experience</h2>
                        <div class="default-title-bdr"></div>
                        <p>It is a long established fact that a reader will be distracted.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="service-col service-item inneer_services_page">
                        <div class="service-icon">
                            <i class="zmdi zmdi-laptop-mac"></i>
                        </div>
                        
                        <p>These days I am doing my co-op at Web-studio Toronto, this is a amazing company where I am working now, they are very professional I have learned many things here. Further, I work as Security Guard in Toronto, this is my favorite job I did a lot of hard-work to get this job, when I came to Canada I face a lot of problems to find work, then someone told me that you should go for Security Job but for that, firstly I got Security Training then, I gave my Exam then after that, I got my License then I gave my Interview. After that I got job, these days I am working with Garda World Security Company according to me they are best people with whom I am working these days. Everyone ask me this question you are in Web-Designing Program then why you choose the Security Job then I always say that I want to be an Police officer so that’s and in the Security field I will get more experience then after that I can get Police job. Its my childhood dream to be an Police Officer its not easy to get this job, but I will do hard-work to get that job soon I know it takes time, but its true that nothing comes easy we need to work for that.</p>
                        <div class="box-bdr"></div>
                    </div>
                </div>  
				</div>                     
                    </div>
              
    </section>

  <?php include 'includes/footer.php' ?>