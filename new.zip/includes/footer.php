    <!-- Copyright Start -->
    <section class="copyright-bar">
        <div class="container">
            <div class="row">
               
                <div class="col-lg-12">
                    <div class="copyright-col text-center text-center991">
                        <p>©2018. All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- jQuery -->
    <script src="<?php echo base_url('assets/js/jquery.min.js')?>"></script>  
    <script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>   
    <script src="<?php echo base_url('assets/js/scrolling-nav.js')?>"></script>
    <script src="<?php echo base_url('assets/js/animated-text.js')?>"></script>
    <script src="<?php echo base_url('assets/js/owl.carousel.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.countup.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/jarallax.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/lightbox.min.js')?>"></script> 
    <script src="<?php echo base_url('assets/js/main.js')?>"></script>
</body>

</html>